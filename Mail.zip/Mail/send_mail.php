<?php

header("Content-Type: application/json");

require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
require 'PHPMailer/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;

$data = json_decode(file_get_contents("php://input"), true);

if (!$data) {
    echo json_encode([
        "success" => false,
        "message" => "No JSON data received"
    ]);
    exit;
}

$email = $data['email'] ?? '';
$subject = $data['subject'] ?? '';
$message = $data['message'] ?? '';

if (empty($email) || empty($subject) || empty($message)) {
    echo json_encode([
        "success" => false,
        "message" => "Missing fields"
    ]);
    exit;
}

$mail = new PHPMailer(true);

try {

    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;

    $mail->Username = 'ghodeom30@gmail.com';
    $mail->Password = 'pvio hwiv vird quoa';

    $mail->SMTPSecure = 'tls';
    $mail->Port = 587;

    $mail->setFrom('ghodeom30@gmail.com', 'Test API');

    $mail->addAddress($email);

    $mail->isHTML(true);

    $mail->Subject = $subject;
    $mail->Body = $message;

    $mail->send();

    echo json_encode([
        "success" => true,
        "message" => "Mail Sent"
    ]);

} catch (Exception $e) {

    echo json_encode([
        "success" => false,
        "error" => $mail->ErrorInfo
    ]);
}
?>